import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Records from "./RecordsComponent/Records";
import Register from "./RegisterComponent/Register";

const App = () => {
  return (
    <Router>
      
        <Routes>
          <Route path="/" element={<Register/>} />
          <Route path="/records" element={<Records/>} />
     

  
        </Routes>
      
    </Router>
  );
};

export default App;
