import React,{useState}from 'react';
import './Register.css';
import axios from "axios";



const Register=()=> {

    class Employee {

        constructor( id,empName,salary,city) {
          this.id = id+1;
          this.empName = empName;
          this.salary=salary;
          this.city = city;
         }  }
   
        const [id, setid] = useState(9);
        const [empName, setempName] = useState(null);
        const [salary, setsalary] = useState(null);
        const [city,setcity] = useState(null);
    

    const HandleSubmit  = () => {
        setid(id + 1);

        if(empName === 'null')
        {
            alert("Please fill the Name of Employee")
        }
        
        if(city === '')
        {
            alert("You must have to enter the address")
        }
    else
    { 
        var EmpId=parseInt(id);
        var Sal=parseInt(salary);
        var employee1 =new Employee(EmpId,empName,Sal,city);
        axios.post('https://localhost:5001/Employees/AddEmp',employee1);
        console.log(EmpId,empName,Sal,city);
        alert("Thank You For Registration");

    }
}


   
  return (
    <div className="form">
          <div className="form-body">
       

              <div className="EmpName">
                  <label className="form_label" for="EmpName">Employee Name : </label>
                  <input className="form_input" type="text" name="EmpName" id="empName"  value={empName} onChange={(e) => {setempName(e.target.value)}} placeholder="EmpName" required/>
              </div>
        
          <div className="Salary">
                  <label className="form_label" for="Salary">Salary : </label>
                  <input  type="number" id="salary" className="form_input" name="Salary"  value={salary} onChange = {(e) => setsalary(e.target.value)} placeholder="Salary" required/>
        
                  </div>
              <div className="City">
                  <label className="form_label" for="City">Address : </label>
                  <input className="form_input" type="text" name="Salary"  id="city"  value={city} onChange = {(e) => setcity(e.target.value)} placeholder="City" required/>
              </div>
          </div>
          <div class="footer">
          <button type="submit" onClick = {()=>HandleSubmit()} class="btn">Register</button> <span>
          <a href='http://localhost:3000/records'>
          <button type="submit"  class="btn">Records</button> </a></span>  
           
          </div>
  
      </div>      
    )       
}

export default Register;




