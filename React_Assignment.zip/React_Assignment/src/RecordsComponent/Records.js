
import React, { useState }  from "react";
import './Records.css';
import  axios from "axios";



class Employee {

    constructor( id,empName,city,salary) {
      this.id = id;
      this.empName = empName;
      this.city = city;
      this.salary=salary;
     }  }

const Records=()=>{

   const[employees,setEmployees]=useState(null);
    const GetAllEmp=()=>{
        axios.get('https://localhost:5001/Employees/GetAllEmp')
        .then((response)=>{
           
         var employees=[];
            response.data.map((e)=> {
              employees.push(new Employee(e.id,e.empName,e.city,e.salary))

            });

          setEmployees(employees);

        });

    }
      return(
        <div>
        <button className="button" onClick={()=>GetAllEmp()}> Display All Employees Data </button>
        <a href='http://localhost:3000/'>
        <button className="button2" > Back to Registration </button></a>
        <br/>
        <br/>
            <table id="Records_table">
                  
                  <tr><th> EmpId </th><th> EmpName </th> <th> Address </th> <th> Salary</th></tr>
                { employees &&
                  employees.map(e =>
                      <tr>
                        <td>{e.id}</td>
                        <td>{e.empName}</td>
                        <td>{e.city}</td>
                        <td>{e.salary}</td>
                      </tr>
                )}
            </table>
        
        </div>);
        
    }
    export default Records;